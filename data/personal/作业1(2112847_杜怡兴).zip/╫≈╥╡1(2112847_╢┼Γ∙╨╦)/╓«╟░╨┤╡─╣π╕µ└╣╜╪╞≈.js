// ==UserScript==
// @name         dyx's Bing Ad Blocker
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Block ads on Bing search results
// @author       dyx
// @match        https://*/*
// @match        http://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to hide ads
    function hideAds() {
        // Select all elements with the specified class names and hide them
        document.querySelectorAll('.b_adTop, .b_adMiddle, .sb_add').forEach(function(ad) {
            ad.style.display = 'none';
        });
    }

    // Run the hideAds function on page load
    window.addEventListener('load', hideAds);

    // For dynamic content, you may want to run hideAds periodically
    setInterval(hideAds, 3000);
})();
