// ==UserScript==
// @name         ChatGPT Chinese Response Helper
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Automatically append "[中文回复]" before sending messages in ChatGPT.
// @author       You
// @match        https://chat.openai.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    console.log("ChatGPT Chinese Response Helper script loaded");

    // Function to append text to the textarea
    function appendText() {
        var textarea = document.querySelector("#prompt-textarea");
        // Check if the "[中文回复]" text is already present
        if (textarea && !textarea.value.includes("[中文回复]")) {
            console.log("Appending [中文回复] to textarea");
            textarea.value += "[中文回复]";
            // Trigger the input event to ensure the UI updates
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
        }
    }

    // Rebind the click event to the send button when detected in DOM changes
    function rebindClickEvent() {
        var sendButton = document.querySelector('[data-testid="send-button"]');
        if (sendButton) {
            // Make sure to remove the previous event listener to avoid duplicates
            sendButton.removeEventListener('click', appendText);
            sendButton.addEventListener('click', appendText);
            console.log("Send button event rebound");
        }
    }

    // Create an observer instance to monitor DOM changes
    var observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                rebindClickEvent();
            }
        });
    });

    // Start observing the document body for DOM changes
    observer.observe(document.body, { childList: true, subtree: true });

    // Initial binding in case the button exists before the observer starts
    rebindClickEvent();
})();
